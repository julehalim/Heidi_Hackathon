"use client"

import { useState } from "react"
import { useConversation } from "@/lib/elevenlabs-react"
import { Mic, MicOff, MessageCircle, ArrowLeft, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import { useRouter } from "next/navigation"

/* ---------- page component ---------- */
export default function ScreeningPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="flex items-center justify-center py-10">
        <VoiceAgentWidget />
      </main>
    </div>
  )
}

/* ---------- header ---------- */
function Header() {
  const router = useRouter()
  return (
    <header className="border-b bg-white shadow-sm">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <div className="flex items-center space-x-3">
          <Image
            src="/heidi-logo.png"
            alt="Heidi Logo"
            width={32}
            height={32}
            className="rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 p-1"
          />
          <h1 className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-xl font-semibold text-transparent">
            Find&nbsp;my&nbsp;Trial
          </h1>
        </div>
        <Button variant="outline" size="sm" onClick={() => router.push("/dashboard")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
      </div>
    </header>
  )
}

/* ---------- voice widget ---------- */
function VoiceAgentWidget() {
  const [agentId, setAgentId] = useState("agent_01jzngz7rdftttj64yhsagd1a1")
  const [apiKey, setApiKey] = useState("sk_99939845097a48f054e3f9030210f7ed7e2ebebea0749287")
  const [isConfigured, setIsConfigured] = useState(true)

  const convo = useConversation({
    onError: (e) => alert(e.message),
  })

  const start = () =>
    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then(() => convo.startSession({ agentId }))
      .catch(() => alert("Microphone permission denied"))

  return (
    <Card className="w-full max-w-md border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50 shadow-xl">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center space-x-2 text-xl">
          <MessageCircle className="h-6 w-6 text-purple-600" />
          <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Yu&nbsp;AI</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* status icon */}
        <div className="text-center">
          <div
            className={`mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full transition-all ${
              convo.status === "connected"
                ? "animate-pulse bg-gradient-to-r from-green-400 to-emerald-500"
                : "bg-gradient-to-r from-purple-400 to-blue-500"
            }`}
          >
            {convo.status === "connected" ? (
              <MicOff className="h-8 w-8 text-white" />
            ) : (
              <Mic className="h-8 w-8 text-white" />
            )}
          </div>
          <p className="text-sm text-gray-600">
            {convo.status === "connected" ? "Yu AI is listening…" : "Click to start conversation"}
          </p>
        </div>

        {/* buttons */}
        <div className="flex space-x-2">
          {convo.status !== "connected" ? (
            <Button
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700"
              disabled={!isConfigured}
              onClick={start}
            >
              <Mic className="mr-2 h-4 w-4" /> Start Chat
            </Button>
          ) : (
            <Button variant="destructive" className="flex-1" onClick={convo.endSession}>
              <MicOff className="mr-2 h-4 w-4" /> End Chat
            </Button>
          )}

          {/* settings dialog (optional) */}
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon">
                <Settings className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Configure ElevenLabs</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="agentId">Agent&nbsp;ID</Label>
                  <Input id="agentId" value={agentId} onChange={(e) => setAgentId(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="apiKey">API&nbsp;Key</Label>
                  <Input id="apiKey" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} />
                </div>
                <Button onClick={() => setIsConfigured(Boolean(apiKey))} className="w-full">
                  Save
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* simple transcript */}
        <div className="max-h-40 overflow-y-auto rounded-lg bg-gray-100 p-3 text-sm">
          {convo.messages.map((m, i) => (
            <p key={i} className={m.from === "user" ? "text-right text-blue-800" : "text-purple-800"}>
              <span className="font-medium">{m.from === "user" ? "You: " : "Yu AI: "}</span>
              {m.text}
            </p>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
