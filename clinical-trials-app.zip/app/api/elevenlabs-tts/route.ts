import { NextResponse } from "next/server"

export const maxDuration = 60

export async function POST(req: Request) {
  const { text } = await req.json()

  if (!text) {
    return new NextResponse("Text is required", { status: 400 })
  }

  const ELEVEN_LABS_API_KEY = process.env.ELEVEN_LABS_API_KEY
  const ELEVEN_LABS_VOICE_ID = process.env.ELEVEN_LABS_VOICE_ID || "21m00Tcm4TlvDq8ikWAM" // Default voice if not provided

  if (!ELEVEN_LABS_API_KEY) {
    console.error("ELEVEN_LABS_API_KEY is not set in environment variables.")
    return new NextResponse("Server error: Eleven Labs API key is missing.", { status: 500 })
  }

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${ELEVEN_LABS_VOICE_ID}/stream`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "xi-api-key": ELEVEN_LABS_API_KEY,
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_turbo_v2", // Using a fast model for conversational AI
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.8,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Eleven Labs API error: Status ${response.status}, Body: ${errorText}`)
      // Attempt to parse as JSON, but fall back to raw text
      try {
        const errorData = JSON.parse(errorText)
        return new NextResponse(
          JSON.stringify({ message: `Eleven Labs API error: ${errorData.detail || errorText}` }),
          { status: response.status },
        )
      } catch (e) {
        return new NextResponse(JSON.stringify({ message: `Eleven Labs API error: ${errorText}` }), {
          status: response.status,
        })
      }
    }

    // Stream the audio directly to the client
    return new NextResponse(response.body, {
      headers: {
        "Content-Type": "audio/mpeg",
        "Cache-Control": "no-cache",
      },
    })
  } catch (error: any) {
    console.error("Error calling Eleven Labs API:", error.message || error)
    return new NextResponse(JSON.stringify({ message: `Internal Server Error: ${error.message || "Unknown error"}` }), {
      status: 500,
    })
  }
}
