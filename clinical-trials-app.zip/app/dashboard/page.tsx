"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { User, Mic, LogOut, Calendar, MapPin, Heart } from "lucide-react"
import Image from "next/image"

const defaultPatientInfo: PatientInfo = {
  dateOfBirth: "",
  conditions: "",
  medications: "",
  allergies: "",
  location: "",
}

interface PatientInfo {
  dateOfBirth: string
  conditions: string
  medications: string
  allergies: string
  location: string
}

export default function Dashboard() {
  const [showConsentModal, setShowConsentModal] = useState(false)
  const [showPatientInfoModal, setShowPatientInfoModal] = useState(false)
  const [consentGiven, setConsentGiven] = useState(false)
  const [patientInfoCompleted, setPatientInfoCompleted] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const [agreedToTerms, setAgreedToTerms] = useState(false)
  const [agreedToPrivacy, setAgreedToPrivacy] = useState(false)

  // Patient information form state
  const [patientInfo, setPatientInfo] = useState<PatientInfo>({ ...defaultPatientInfo })

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const email = localStorage.getItem("userEmail")
    const consent = localStorage.getItem("consentGiven")
    const patientInfoData = localStorage.getItem("patientInfo")

    if (!isLoggedIn) {
      window.location.href = "/"
      return
    }

    setUserEmail(email || "")

    if (!consent) {
      setShowConsentModal(true)
    } else {
      setConsentGiven(true)

      if (!patientInfoData) {
        setShowPatientInfoModal(true)
      } else {
        setPatientInfoCompleted(true)
        setPatientInfo({ ...defaultPatientInfo, ...JSON.parse(patientInfoData) })
      }
    }
  }, [])

  const handleConsent = () => {
    if (agreedToTerms && agreedToPrivacy) {
      localStorage.setItem("consentGiven", "true")
      setConsentGiven(true)
      setShowConsentModal(false)
      setShowPatientInfoModal(true)
    }
  }

  const handlePatientInfoSubmit = () => {
    // Validate that required fields are filled
    const { dateOfBirth = "", conditions = "", location = "" } = patientInfo

    if (!dateOfBirth.trim() || !conditions.trim() || !location.trim()) {
      alert("Please fill in your date of birth, medical conditions, and location.")
      return
    }

    localStorage.setItem("patientInfo", JSON.stringify(patientInfo))
    setPatientInfoCompleted(true)
    setShowPatientInfoModal(false)
  }

  const handlePatientInfoChange = (field: keyof PatientInfo, value: string) => {
    setPatientInfo((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleLogout = () => {
    localStorage.clear()
    window.location.href = "/"
  }

  const goToApplications = () => {
    window.location.href = "/applications"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Image
                src="/heidi-logo.png"
                alt="Heidi Logo"
                width={32}
                height={32}
                className="bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg p-1"
              />
              <h1 className="text-xl font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Find my Trial
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-700">{userEmail}</span>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Welcome Section */}
          <div
            className="rounded-lg p-6 text-white relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, #E91E63 0%, #9C27B0 50%, #3F51B5 100%)",
            }}
          >
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-2">Welcome to Your Clinical Trial Journey</h2>
              <p className="text-white/90">
                With Heidi, you can discover personalised clinical trial opportunities that match your health profile
                and preferences.
              </p>
            </div>
          </div>

          {/* Action Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow border-purple-200 hover:border-purple-300">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-gradient-to-br from-green-400 to-green-600 rounded-lg">
                    <Mic className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-gray-900">AI Screening</CardTitle>
                </div>
                <CardDescription>Complete your personalized screening with our AI voice assistant</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => (window.location.href = "/screening")}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                >
                  Start AI Screening
                </Button>
              </CardContent>
            </Card>

            <Card className="border-purple-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg">
                    <Calendar className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-gray-900">My Applications</CardTitle>
                </div>
                <CardDescription>Track your clinical trial applications and status</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={goToApplications}
                  className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                >
                  View Applications
                </Button>
              </CardContent>
            </Card>

            <Card className="border-purple-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg">
                    <MapPin className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-gray-900">Nearby Trials</CardTitle>
                </div>
                <CardDescription>Find clinical trials in your area</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full border-purple-200 text-gray-500 bg-transparent" disabled>
                  Browse Trials
                </Button>
                <p className="text-xs text-gray-500 mt-2">Complete screening first</p>
              </CardContent>
            </Card>
          </div>

          {/* Status Section */}
          <Card className="border-purple-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Your Progress</CardTitle>
              <CardDescription>Complete these steps to find matching clinical trials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-400 to-green-600 flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <span className="text-sm text-gray-700">Account created and verified</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-6 h-6 rounded-full ${
                      consentGiven ? "bg-gradient-to-r from-green-400 to-green-600" : "bg-gray-300"
                    } flex items-center justify-center`}
                  >
                    <span className="text-white text-xs">{consentGiven ? "✓" : "2"}</span>
                  </div>
                  <span className="text-sm text-gray-700">Terms and conditions accepted</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-6 h-6 rounded-full ${
                      patientInfoCompleted ? "bg-gradient-to-r from-green-400 to-green-600" : "bg-gray-300"
                    } flex items-center justify-center`}
                  >
                    <span className="text-white text-xs">{patientInfoCompleted ? "✓" : "3"}</span>
                  </div>
                  <span className="text-sm text-gray-700">Basic health information provided</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center">
                    <span className="text-white text-xs">4</span>
                  </div>
                  <span className="text-sm text-gray-500">Complete AI screening assessment</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center">
                    <span className="text-white text-xs">5</span>
                  </div>
                  <span className="text-sm text-gray-500">Review personalized trial recommendations</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Consent Modal - Fixed scrolling issue */}
      <Dialog open={showConsentModal} onOpenChange={() => {}}>
        <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-xl font-bold text-gray-900">Clinical Trial Participation Consent</DialogTitle>
            <DialogDescription className="text-gray-600">
              Please review and accept our terms to participate in clinical trial matching
            </DialogDescription>
          </DialogHeader>

          {/* Fixed scrollable content */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-full max-h-[50vh] w-full rounded border p-4 bg-gray-50">
              <div className="space-y-6 text-sm text-gray-700 pr-4">
                <section>
                  <h3 className="font-semibold text-base mb-3 text-purple-700">Terms and Conditions</h3>
                  <p className="mb-3">
                    By participating in our clinical trial matching service, you agree to the following terms:
                  </p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>You consent to sharing your medical information for trial matching purposes</li>
                    <li>You understand that participation in clinical trials is voluntary</li>
                    <li>You acknowledge that we will connect you with appropriate research opportunities</li>
                    <li>You agree to provide accurate and complete health information</li>
                    <li>You understand that final eligibility is determined by the research teams</li>
                    <li>You can withdraw from our service at any time without penalty</li>
                    <li>We will notify you of relevant trial opportunities based on your profile</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-semibold text-base mb-3 text-purple-700">Privacy Policy</h3>
                  <p className="mb-3">Your privacy and data security are our top priorities:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>All health information is encrypted and HIPAA compliant</li>
                    <li>Data is only shared with authorized research institutions</li>
                    <li>You can withdraw consent and delete your data at any time</li>
                    <li>We use secure, industry-standard data protection measures</li>
                    <li>Your identity remains confidential throughout the matching process</li>
                    <li>We do not sell or share your data with third parties for marketing</li>
                    <li>Regular security audits ensure your data remains protected</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-semibold text-base mb-3 text-purple-700">AI Voice Screening</h3>
                  <p className="mb-3">Our AI screening process involves:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Voice-based questionnaire about your health conditions</li>
                    <li>Analysis of your responses to match with suitable trials</li>
                    <li>Personalized recommendations based on your profile</li>
                    <li>No recording of personal identifiers in voice data</li>
                    <li>Secure processing of all voice interactions</li>
                    <li>Option to review and modify your responses</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-semibold text-base mb-3 text-purple-700">Data Usage and Retention</h3>
                  <p className="mb-3">How we handle your information:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Data is retained only as long as necessary for matching services</li>
                    <li>You can request data deletion at any time</li>
                    <li>Anonymized data may be used for research improvement</li>
                    <li>Regular data purging ensures minimal retention</li>
                  </ul>
                </section>
              </div>
            </ScrollArea>
          </div>

          {/* Fixed footer section */}
          <div className="flex-shrink-0 space-y-4 pt-4 border-t border-gray-200">
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="terms"
                  checked={agreedToTerms}
                  onCheckedChange={setAgreedToTerms}
                  className="mt-0.5 border-purple-300 data-[state=checked]:bg-purple-600"
                />
                <label htmlFor="terms" className="text-sm font-medium leading-relaxed text-gray-700 cursor-pointer">
                  I have read and agree to the Terms and Conditions for clinical trial participation
                </label>
              </div>
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="privacy"
                  checked={agreedToPrivacy}
                  onCheckedChange={setAgreedToPrivacy}
                  className="mt-0.5 border-purple-300 data-[state=checked]:bg-purple-600"
                />
                <label htmlFor="privacy" className="text-sm font-medium leading-relaxed text-gray-700 cursor-pointer">
                  I have read and agree to the Privacy Policy and data handling practices
                </label>
              </div>
            </div>

            <DialogFooter>
              <Button
                onClick={handleConsent}
                disabled={!agreedToTerms || !agreedToPrivacy}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
                size="lg"
              >
                Accept and Continue
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Patient Information Modal */}
      <Dialog open={showPatientInfoModal} onOpenChange={() => {}}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader>
            <div className="flex items-center space-x-2 mb-2">
              <div className="p-2 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <DialogTitle className="text-xl font-bold text-gray-900">Basic Health Information</DialogTitle>
            </div>
            <DialogDescription className="text-gray-600">
              Please provide some basic information to help us match you with suitable clinical trials. This information
              will be used to pre-screen potential matches.
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="max-h-[60vh] pr-4">
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth" className="text-sm font-medium text-gray-700">
                    Date of Birth <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={patientInfo.dateOfBirth}
                    onChange={(e) => handlePatientInfoChange("dateOfBirth", e.target.value)}
                    className="border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                    required
                    max={new Date().toISOString().split("T")[0]} // Prevent future dates
                  />
                  <p className="text-xs text-gray-500">
                    Your age helps us match you with age-appropriate clinical trials
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="conditions" className="text-sm font-medium text-gray-700">
                    Medical Conditions <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="conditions"
                    placeholder="Please list any medical conditions you have been diagnosed with (e.g., diabetes, hypertension, arthritis, etc.)"
                    value={patientInfo.conditions}
                    onChange={(e) => handlePatientInfoChange("conditions", e.target.value)}
                    className="min-h-[80px] border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="medications" className="text-sm font-medium text-gray-700">
                    Current Medications
                  </Label>
                  <Textarea
                    id="medications"
                    placeholder="List any medications you are currently taking, including dosages if known (e.g., Metformin 500mg twice daily, Lisinopril 10mg once daily, etc.)"
                    value={patientInfo.medications}
                    onChange={(e) => handlePatientInfoChange("medications", e.target.value)}
                    className="min-h-[80px] border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="allergies" className="text-sm font-medium text-gray-700">
                    Allergies
                  </Label>
                  <Textarea
                    id="allergies"
                    placeholder="List any known allergies to medications, foods, or other substances (e.g., penicillin, shellfish, latex, etc.). If none, please write 'None known'"
                    value={patientInfo.allergies}
                    onChange={(e) => handlePatientInfoChange("allergies", e.target.value)}
                    className="min-h-[60px] border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location" className="text-sm font-medium text-gray-700">
                    Location <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="location"
                    placeholder="City, State/Province, Country (e.g., San Francisco, CA, USA)"
                    value={patientInfo.location}
                    onChange={(e) => handlePatientInfoChange("location", e.target.value)}
                    className="border-purple-200 focus:border-purple-500 focus:ring-purple-500"
                    required
                  />
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Why do we need this information?</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>
                    • <strong>Date of birth:</strong> Age is a key eligibility criterion for most clinical trials
                  </li>
                  <li>
                    • <strong>Medical conditions:</strong> To match you with relevant clinical trials
                  </li>
                  <li>
                    • <strong>Medications:</strong> To check for potential drug interactions in trials
                  </li>
                  <li>
                    • <strong>Allergies:</strong> To ensure your safety in trial participation
                  </li>
                  <li>
                    • <strong>Location:</strong> To find trials near you or within travel distance
                  </li>
                </ul>
              </div>
            </div>
          </ScrollArea>

          <DialogFooter className="pt-4 border-t border-gray-200">
            <Button
              onClick={handlePatientInfoSubmit}
              disabled={
                !(patientInfo.dateOfBirth?.trim() && patientInfo.conditions?.trim() && patientInfo.location?.trim())
              }
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
              size="lg"
            >
              Save Information and Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
