"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, MapPin, DollarSign, ExternalLink, Users, Clock, CheckCircle } from "lucide-react"
import Image from "next/image"

interface ClinicalTrial {
  id: string
  title: string
  condition: string
  phase: string
  location: string
  duration: string
  compensation: string
  requirements: string[]
  description: string
  sponsor: string
  contactEmail: string
  website: string
  enrollmentStatus: "Open" | "Closing Soon" | "Full"
  matchScore: number
}

const mockTrials: ClinicalTrial[] = [
  {
    id: "NCT12345678",
    title: "Novel Treatment for Type 2 Diabetes Management",
    condition: "Type 2 Diabetes",
    phase: "Phase III",
    location: "Stanford Medical Center, CA",
    duration: "12 months",
    compensation: "$2,500",
    requirements: [
      "Age 18-75 years",
      "Diagnosed with Type 2 Diabetes",
      "HbA1c between 7-10%",
      "Stable medication regimen",
    ],
    description:
      "This study evaluates a new medication for improving blood sugar control in adults with Type 2 diabetes. The treatment aims to reduce HbA1c levels while minimizing side effects.",
    sponsor: "Stanford University Medical Center",
    contactEmail: "diabetes.study@stanford.edu",
    website: "https://clinicaltrials.gov/ct2/show/NCT12345678",
    enrollmentStatus: "Open",
    matchScore: 95,
  },
  {
    id: "NCT87654321",
    title: "Cardiovascular Health Prevention Study",
    condition: "Cardiovascular Disease Prevention",
    phase: "Phase II",
    location: "Mayo Clinic, MN",
    duration: "18 months",
    compensation: "$3,000",
    requirements: [
      "Age 45-70 years",
      "Family history of heart disease",
      "No current heart conditions",
      "Willing to make lifestyle changes",
    ],
    description:
      "A comprehensive study examining preventive interventions for cardiovascular disease in high-risk individuals. Includes dietary counseling, exercise programs, and investigational supplements.",
    sponsor: "Mayo Clinic Research Foundation",
    contactEmail: "cardio.prevention@mayo.edu",
    website: "https://clinicaltrials.gov/ct2/show/NCT87654321",
    enrollmentStatus: "Open",
    matchScore: 87,
  },
  {
    id: "NCT11223344",
    title: "Advanced Hypertension Management Trial",
    condition: "Hypertension",
    phase: "Phase III",
    location: "Johns Hopkins Hospital, MD",
    duration: "24 months",
    compensation: "$4,200",
    requirements: [
      "Age 30-80 years",
      "Uncontrolled hypertension",
      "Currently on 2+ medications",
      "Regular healthcare access",
    ],
    description:
      "Testing a new combination therapy for patients with difficult-to-control high blood pressure. The study includes regular monitoring and personalized treatment adjustments.",
    sponsor: "Johns Hopkins University",
    contactEmail: "hypertension.trial@jhmi.edu",
    website: "https://clinicaltrials.gov/ct2/show/NCT11223344",
    enrollmentStatus: "Closing Soon",
    matchScore: 82,
  },
]

export default function ResultsPage() {
  const [trials, setTrials] = useState<ClinicalTrial[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [responses, setResponses] = useState<Record<number, string>>({})

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const screeningResponses = localStorage.getItem("screeningResponses")

    if (!isLoggedIn || !screeningResponses) {
      window.location.href = "/dashboard"
      return
    }

    const parsedResponses = JSON.parse(screeningResponses)
    setResponses(parsedResponses)

    // Simulate AI processing and trial matching
    setTimeout(() => {
      setTrials(mockTrials)
      setIsLoading(false)
    }, 2000)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Open":
        return "bg-green-100 text-green-800 border-green-200"
      case "Closing Soon":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Full":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-blue-600"
    if (score >= 70) return "text-yellow-600"
    return "text-gray-600"
  }

  if (isLoading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center relative"
        style={{
          background: "linear-gradient(135deg, #E91E63 0%, #9C27B0 50%, #3F51B5 100%)",
        }}
      >
        <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
              <h3 className="text-lg font-semibold text-gray-900">Processing Your Screening</h3>
              <p className="text-gray-600">
                Our AI is analyzing your responses and matching you with suitable clinical trials...
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Image
                src="/heidi-logo.png"
                alt="Heidi Logo"
                width={32}
                height={32}
                className="bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg p-1"
              />
              <h1 className="text-xl font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Find my Trial - Matches
              </h1>
            </div>
            <Button variant="outline" onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Summary */}
          <Card
            className="border-green-200 relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%)",
            }}
          >
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <h2 className="text-xl font-semibold text-gray-900">Screening Complete!</h2>
              </div>
              <p className="text-gray-700 mb-4">
                Based on your responses, we've found {trials.length} clinical trials that match your profile. Each trial
                has been scored based on your eligibility and preferences.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-purple-200">
                  <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {trials.length}
                  </div>
                  <div className="text-sm text-gray-600">Matching Trials</div>
                </div>
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-green-200">
                  <div className="text-2xl font-bold text-green-600">
                    {trials.filter((t) => t.matchScore >= 90).length}
                  </div>
                  <div className="text-sm text-gray-600">High Matches (90%+)</div>
                </div>
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-blue-200">
                  <div className="text-2xl font-bold text-blue-600">
                    {trials.filter((t) => t.enrollmentStatus === "Open").length}
                  </div>
                  <div className="text-sm text-gray-600">Currently Enrolling</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Trial Results */}
          <div className="space-y-6">
            {trials.map((trial) => (
              <Card key={trial.id} className="hover:shadow-lg transition-shadow border-purple-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="border-purple-300 text-purple-700">
                          {trial.phase}
                        </Badge>
                        <Badge className={getStatusColor(trial.enrollmentStatus)}>{trial.enrollmentStatus}</Badge>
                        <Badge variant="secondary" className="bg-pink-100 text-pink-800">
                          {trial.condition}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl text-gray-900">{trial.title}</CardTitle>
                      <CardDescription className="text-base text-gray-600">{trial.description}</CardDescription>
                    </div>
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${getMatchScoreColor(trial.matchScore)}`}>
                        {trial.matchScore}%
                      </div>
                      <div className="text-sm text-gray-500">Match Score</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Key Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-purple-500" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">Location</div>
                        <div className="text-sm text-gray-600">{trial.location}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-purple-500" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">Duration</div>
                        <div className="text-sm text-gray-600">{trial.duration}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-purple-500" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">Compensation</div>
                        <div className="text-sm text-gray-600">{trial.compensation}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-purple-500" />
                      <div>
                        <div className="text-sm font-medium text-gray-900">Sponsor</div>
                        <div className="text-sm text-gray-600">{trial.sponsor}</div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Requirements */}
                  <div>
                    <h4 className="font-medium mb-2 text-gray-900">Key Requirements:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {trial.requirements.map((req, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{req}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                      className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                      asChild
                    >
                      <a href={trial.website} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Full Details
                      </a>
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
                      asChild
                    >
                      <a href={`mailto:${trial.contactEmail}?subject=Interest in ${trial.title} (${trial.id})`}>
                        Contact Research Team
                      </a>
                    </Button>
                  </div>

                  {/* Trial ID */}
                  <div className="text-xs text-gray-500">Trial ID: {trial.id}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Next Steps */}
          <Card className="bg-purple-50 border-purple-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Next Steps</CardTitle>
              <CardDescription>Here's what you should do to move forward with these clinical trials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center justify-center text-sm font-medium">
                    1
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Review Trial Details</h4>
                    <p className="text-sm text-gray-600">
                      Click "View Full Details" to read complete trial information on ClinicalTrials.gov
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center justify-center text-sm font-medium">
                    2
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Contact Research Teams</h4>
                    <p className="text-sm text-gray-600">
                      Reach out to trials that interest you using the provided contact information
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center justify-center text-sm font-medium">
                    3
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Prepare for Screening</h4>
                    <p className="text-sm text-gray-600">
                      Gather your medical records and prepare for additional screening by the research team
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white flex items-center justify-center text-sm font-medium">
                    4
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Consult Your Doctor</h4>
                    <p className="text-sm text-gray-600">
                      Discuss participation with your healthcare provider before enrolling
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
