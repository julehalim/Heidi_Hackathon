"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, MapPin, Clock, CheckCircle, AlertCircle, FileText } from "lucide-react"
import Image from "next/image"

interface Application {
  id: string
  trialTitle: string
  condition: string
  status: "Applied" | "Under Review" | "Accepted" | "Declined" | "Completed"
  appliedDate: string
  location: string
  nextStep: string
  contactEmail: string
}

const mockApplications: Application[] = [
  {
    id: "APP001",
    trialTitle: "Novel Treatment for Type 2 Diabetes Management",
    condition: "Type 2 Diabetes",
    status: "Under Review",
    appliedDate: "2024-01-15",
    location: "Stanford Medical Center, CA",
    nextStep: "Awaiting initial screening results",
    contactEmail: "diabetes.study@stanford.edu",
  },
  {
    id: "APP002",
    trialTitle: "Cardiovascular Health Prevention Study",
    condition: "Cardiovascular Disease Prevention",
    status: "Accepted",
    appliedDate: "2024-01-10",
    location: "Mayo Clinic, MN",
    nextStep: "Schedule baseline visit",
    contactEmail: "cardio.prevention@mayo.edu",
  },
  {
    id: "APP003",
    trialTitle: "Advanced Hypertension Management Trial",
    condition: "Hypertension",
    status: "Applied",
    appliedDate: "2024-01-20",
    location: "Johns Hopkins Hospital, MD",
    nextStep: "Initial application submitted",
    contactEmail: "hypertension.trial@jhmi.edu",
  },
]

export default function ApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([])
  const [userEmail, setUserEmail] = useState("")

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const email = localStorage.getItem("userEmail")

    if (!isLoggedIn) {
      window.location.href = "/"
      return
    }

    setUserEmail(email || "")
    setApplications(mockApplications)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Applied":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "Under Review":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Accepted":
        return "bg-green-100 text-green-800 border-green-200"
      case "Declined":
        return "bg-red-100 text-red-800 border-red-200"
      case "Completed":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Applied":
        return <FileText className="h-4 w-4" />
      case "Under Review":
        return <Clock className="h-4 w-4" />
      case "Accepted":
        return <CheckCircle className="h-4 w-4" />
      case "Declined":
        return <AlertCircle className="h-4 w-4" />
      case "Completed":
        return <CheckCircle className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Image
                src="/heidi-logo.png"
                alt="Heidi Logo"
                width={32}
                height={32}
                className="bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg p-1"
              />
              <h1 className="text-xl font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Find my Trial - Applications
              </h1>
            </div>
            <Button variant="outline" onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Summary */}
          <Card
            className="border-purple-200 relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(168, 85, 247, 0.1) 0%, rgba(236, 72, 153, 0.1) 100%)",
            }}
          >
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 mb-4">
                <Calendar className="h-6 w-6 text-purple-600" />
                <h2 className="text-xl font-semibold text-gray-900">Application Overview</h2>
              </div>
              <p className="text-gray-700 mb-4">
                Track the status of your clinical trial applications and stay updated on next steps.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-blue-200">
                  <div className="text-2xl font-bold text-blue-600">
                    {applications.filter((app) => app.status === "Applied").length}
                  </div>
                  <div className="text-sm text-gray-600">Applied</div>
                </div>
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-yellow-200">
                  <div className="text-2xl font-bold text-yellow-600">
                    {applications.filter((app) => app.status === "Under Review").length}
                  </div>
                  <div className="text-sm text-gray-600">Under Review</div>
                </div>
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-green-200">
                  <div className="text-2xl font-bold text-green-600">
                    {applications.filter((app) => app.status === "Accepted").length}
                  </div>
                  <div className="text-sm text-gray-600">Accepted</div>
                </div>
                <div className="text-center p-3 bg-white/80 backdrop-blur-sm rounded-lg border border-purple-200">
                  <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {applications.length}
                  </div>
                  <div className="text-sm text-gray-600">Total Applications</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Applications List */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Your Applications</h3>
            {applications.length > 0 ? (
              applications.map((application) => (
                <Card key={application.id} className="hover:shadow-lg transition-shadow border-purple-200">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(application.status)}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(application.status)}
                              <span>{application.status}</span>
                            </div>
                          </Badge>
                          <Badge variant="secondary" className="bg-pink-100 text-pink-800">
                            {application.condition}
                          </Badge>
                        </div>
                        <CardTitle className="text-xl text-gray-900">{application.trialTitle}</CardTitle>
                        <CardDescription className="text-base text-gray-600">
                          Application ID: {application.id}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Application Details */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-purple-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">Applied Date</div>
                          <div className="text-sm text-gray-600">
                            {new Date(application.appliedDate).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-purple-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">Location</div>
                          <div className="text-sm text-gray-600">{application.location}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-purple-500" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">Next Step</div>
                          <div className="text-sm text-gray-600">{application.nextStep}</div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
                      <Button
                        variant="outline"
                        className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
                        asChild
                      >
                        <a
                          href={`mailto:${application.contactEmail}?subject=Application Update Request - ${application.id}`}
                        >
                          Contact Research Team
                        </a>
                      </Button>
                      <Button
                        className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                        disabled
                      >
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="text-center py-12">
                <CardContent>
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Applications Yet</h3>
                  <p className="text-gray-600 mb-4">
                    You haven't applied to any clinical trials yet. Complete your screening to get personalized
                    recommendations.
                  </p>
                  <Button
                    onClick={() => (window.location.href = "/screening")}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                  >
                    Start Screening
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
