"use client"

/**
 * Very-light mock of the Eleven Labs React SDK.
 * Replaces the earlier version that tried to import "web-speech-api".
 */

import { useCallback, useEffect, useRef, useState } from "react"

/* ---------- helpers ---------- */
const SpeechRecognitionCtor: any =
  typeof window !== "undefined"
    ? // Standard or prefixed ctor
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    : undefined

type Message = { from: "user" | "agent"; text: string }

interface Options {
  onConnect?: () => void
  onDisconnect?: () => void
  onMessage?: (m: Message) => void
  onError?: (e: Error) => void
}

export interface Conversation {
  status: "idle" | "connecting" | "connected" | "disconnected"
  isSpeaking: boolean
  messages: Message[]
  startSession: (opts: { agentId: string }) => Promise<void>
  endSession: () => Promise<void>
  sendMessage: (text: string) => Promise<void>
}

/* ---------- hook ---------- */
export function useConversation(opts: Options = {}): Conversation {
  const [status, setStatus] = useState<Conversation["status"]>("idle")
  const [messages, setMessages] = useState<Message[]>([])
  const [isSpeaking, setIsSpeaking] = useState(false)
  const recoRef = useRef<any>(null)

  /* --- synth helper (fake TTS) --- */
  const speak = useCallback(
    async (text: string) => {
      setIsSpeaking(true)
      setMessages((m) => [...m, { from: "agent", text }])
      opts.onMessage?.({ from: "agent", text })

      // use SpeechSynthesis to demo voice
      try {
        const utter = new SpeechSynthesisUtterance(text)
        utter.onend = () => setIsSpeaking(false)
        window.speechSynthesis.speak(utter)
      } catch (e) {
        setIsSpeaking(false)
      }
    },
    [opts],
  )

  /* --- start / end --- */
  const startSession = useCallback(
    async ({ agentId }: { agentId: string }) => {
      if (status !== "idle" && status !== "disconnected") return
      setStatus("connecting")
      try {
        // set up speech-to-text if supported
        if (SpeechRecognitionCtor) {
          recoRef.current = new SpeechRecognitionCtor()
          recoRef.current.lang = "en-US"
          recoRef.current.continuous = true
          recoRef.current.onresult = (ev: any) => {
            const txt = Array.from(ev.results)
              .map((r: any) => r[0].transcript)
              .join("")
            setMessages((m) => [...m, { from: "user", text: txt }])
            opts.onMessage?.({ from: "user", text: txt })
            // echo bot reply
            speak(`You said: ${txt}`)
          }
          recoRef.current.start()
        }
        setStatus("connected")
        opts.onConnect?.()
        speak("Hello, I am Yu AI. How can I help you today?")
      } catch (e: any) {
        setStatus("disconnected")
        opts.onError?.(e)
      }
    },
    [opts, speak, status],
  )

  const endSession = useCallback(async () => {
    recoRef.current?.stop?.()
    setStatus("disconnected")
    opts.onDisconnect?.()
  }, [opts])

  /* --- manual send (text box etc.) --- */
  const sendMessage = useCallback(
    async (text: string) => {
      setMessages((m) => [...m, { from: "user", text }])
      opts.onMessage?.({ from: "user", text })
      await speak(`I received: ${text}`)
    },
    [opts, speak],
  )

  /* cleanup */
  useEffect(() => {
    return () => recoRef.current?.stop?.()
  }, [])

  return { status, isSpeaking, messages, startSession, endSession, sendMessage }
}
